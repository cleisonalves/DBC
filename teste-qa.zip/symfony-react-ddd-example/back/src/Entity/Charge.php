<?php

namespace App\Entity;

use DDD\Model\Charge\Charge as ChargeModel;
class Charge extends ChargeModel
{

}
