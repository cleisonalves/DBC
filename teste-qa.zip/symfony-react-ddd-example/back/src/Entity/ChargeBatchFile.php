<?php

namespace App\Entity;

use DDD\Model\ChargeBatchFile\ChargeBatchFile as ChargeBatchFileModel;
class ChargeBatchFile extends ChargeBatchFileModel
{

}
