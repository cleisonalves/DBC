<?php

namespace DDD\Application\Event;

interface Event
{

}
