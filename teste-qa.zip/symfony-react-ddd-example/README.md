# TESTE QA - Brasiltecpar

Você foi contratado pela empresa **BrasilUploads** para testar os softwares da empresa.
A **BrasilUploads** lançou uma nova funcionalidade em um dos seus sistema que permite cadastrar clientes em massa por meio de um upload de planilha. Os vendedores estão anciosos por essa funcionalidae, pois isso representará um granho expressivo na produtividade dos seus colaboradores. 

Contudo, antes de lançar essa funcionalidade para os seus vendedores, a **BrasilUploads** precisa que você valide se a ferramenta está de fato funcional.

Essa ferramenta foi realizada pelo time Juniors da **BrasilUploads** e é provável que possa ocorrer erros no momento do processamento.


### Brasil Uploader 1.0
A ferramenta consiste de um único campo que recebe a planilha que será processado. Ao ser realizado o upload da planilha, ela será enviada para uma fila no RabbitMQ que fará a inserção de cada linha no banco de dados.

Após a inserção, será possível visualizar a listagem das planilhas importadas. Ao clicar em cada uma das linhas, é possível visualizar os detalhes do upload.

**A ferramenta pode conter alguns bugs**

### Tarefas
- Subir a aplicação;
- Criar e escrever os casos de testes;
- Testar todo o fluxo da aplicação (inserção na fila de processamento, inserção no banco de dados, upload, listagem etc);
- Automatizar testes realizados;
- Evidenciar erros e bugs encontrandos;


### O que esperamos com o teste?
- Criatividade para testar a aplicação com diferentes cenários;
- Capacidade análitica de encontrar problemas;
- Capacidade técnica de evidenciar e automatizar processos;

### Diferenciais
- Conseguir testar a integração com o rabbitmq;
- Apontar onde estão os problemas no código base;
- Sugerir mudanças ou melhorias na aplicação;